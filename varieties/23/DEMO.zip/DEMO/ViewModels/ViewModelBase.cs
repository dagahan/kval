// Вариант 23
using CommunityToolkit.Mvvm.ComponentModel;

namespace DEMO.ViewModels;

public abstract class ViewModelBase : ObservableObject { }
