// Вариант 25
using CommunityToolkit.Mvvm.ComponentModel;

namespace DEMO.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
    // Базовый класс для всех моделей представления.
}
