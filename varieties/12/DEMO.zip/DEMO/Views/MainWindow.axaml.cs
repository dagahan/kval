// Вариант 12
using Avalonia.Controls;

namespace DEMO.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
